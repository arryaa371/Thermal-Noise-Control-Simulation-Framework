def info():
    print('Utility functions placeholder.')
