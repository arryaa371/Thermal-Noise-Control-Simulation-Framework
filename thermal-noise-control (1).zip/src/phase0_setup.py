
import matplotlib.pyplot as plt

# --- Publication-style plotting setup ---
plt.rcParams.update({
    "text.usetex": False,
    "font.family": "serif",
    "axes.labelsize": 14,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "figure.titlesize": 16,
})

print("Plotting environment configured for LaTeX-style output.")
