
import matplotlib.pyplot as plt
import numpy as np

D=np.array([0.0,0.05,0.1,0.25,0.5,0.75,1.0,1.5,2.0])
J=np.array([2.5879,2.7240,2.8566,3.2166,3.7619,4.2711,4.6952,5.4726,6.1886])
J_th=2.610-0.072*np.linspace(0,0.3,100)

plt.figure(figsize=(6,4))
plt.plot(D,J,'o-',label='MC (N=10000)')
plt.plot(np.linspace(0,0.3,100),J_th,'r--',label='Theory')
plt.xlabel('D'); plt.ylabel('<J>')
plt.title('Monte Carlo Energy Scaling (N=10000)')
plt.legend(); plt.grid(True,alpha=0.3)
plt.tight_layout(); plt.savefig("../data/fig_MC_prediction_N10000.png",dpi=300)
