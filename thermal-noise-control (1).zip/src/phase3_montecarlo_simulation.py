
import numpy as np, matplotlib.pyplot as plt

T=1.0; K=5.0
def Vp(x): return 4*x*(x**2-1)

def monte_carlo(D,N=10000,dt=0.001):
    xs=np.full(N,-1.0); Js=np.zeros(N)
    t_grid=np.linspace(0,T,int(T/dt))
    for i,t in enumerate(t_grid):
        u_fb=K*(1-xs)
        Js+=0.5*u_fb**2*dt
        dW=np.sqrt(dt)*np.random.randn(N)
        xs+=(-Vp(xs)+u_fb)*dt+np.sqrt(2*D)*dW
    return Js

D_list=[0,0.05,0.1,0.25,0.5,0.75,1.0,1.5,2.0]
means=[]
for D in D_list:
    Js=monte_carlo(D)
    means.append(np.mean(Js))
    print(D,np.mean(Js))
plt.plot(D_list,means,'o-')
plt.xlabel('D'); plt.ylabel('<J>')
plt.title('MC Energy Scaling (N=10000)')
plt.tight_layout(); plt.savefig("../data/phase3_MC_scaling.png",dpi=200)
