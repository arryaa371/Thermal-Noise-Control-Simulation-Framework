
import numpy as np, matplotlib.pyplot as plt
from scipy.linalg import solve_banded

T=1.0; Nx=200; Nt=200; x_min,x_max=-1.6,1.6; D=0.5
x=np.linspace(x_min,x_max,Nx); dx=x[1]-x[0]; dt=T/Nt

def Vp(x): return 4*x*(x**2-1)
V=0.5*200*(x-1)**2
V_store=np.zeros((Nt+1,Nx)); V_store[-1,:]=V
alpha=D*dt/dx**2
ab=np.zeros((3,Nx)); ab[0,1:]=-alpha; ab[1,:]=1+2*alpha; ab[2,:-1]=-alpha

for it in range(Nt-1,-1,-1):
    Vx=np.gradient(V,x)
    rhs=V+dt*(0.5*np.clip(Vx,-50,50)**2 + Vp(x)*np.clip(Vx,-50,50))
    V=solve_banded((1,1),ab,rhs)
    V_store[it,:]=V

u_field=-np.gradient(V_store,x,axis=1)
np.save("../data/V_store_Nt200.npy",V_store)
np.save("../data/u_field_Nt200.npy",u_field)

plt.imshow(u_field,origin='lower',aspect='auto',extent=[x_min,x_max,0,T])
plt.colorbar(label='u(t,x)'); plt.xlabel('x'); plt.ylabel('t')
plt.title('u field (HJB, Nt=200)')
plt.tight_layout(); plt.savefig("../data/phase2_HJB_field.png",dpi=200)
