
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

def Vp(x): return 4*x*(x**2 - 1)
def Vpp(x): return 12*x**2 - 4
T = 1.0

def dynamics(t, y):
    x, p = y
    return [-Vp(x) - p, p * Vpp(x)]

def integrate_forward(p0, t_eval=None):
    y0 = [-1.0, p0]
    if t_eval is None:
        t_eval = np.linspace(0, T, 501)
    sol = solve_ivp(dynamics, [0, T], y0, t_eval=t_eval)
    return sol.t, sol.y[0], sol.y[1]

# Shooting for correct boundary condition
pl, ph = -3.5, -0.5
for _ in range(60):
    pm = 0.5*(pl+ph)
    t = np.linspace(0, T, 501)
    _, x_low, _ = integrate_forward(pl, t)
    _, x_mid, _ = integrate_forward(pm, t)
    if (x_low[-1]-1.0)*(x_mid[-1]-1.0) <= 0:
        ph = pm
    else:
        pl = pm
p0_est = 0.5*(pl+ph)
t, x_star, p_star = integrate_forward(p0_est, np.linspace(0, T, 501))
u_star = -p_star
J0 = 0.5*np.trapz(u_star**2, t)
print(f"p0_est = {p0_est:.4f}, J0 = {J0:.4f}")

plt.figure(figsize=(6,4))
plt.plot(t, x_star, label="x*(t)")
plt.plot(t, p_star, label="p*(t)")
plt.plot(t, u_star, label="u*(t)=-p*(t)")
plt.legend(); plt.xlabel("t"); plt.ylabel("State / Control")
plt.title("Deterministic Optimal Trajectories")
plt.tight_layout(); plt.savefig("../data/phase1_deterministic.png", dpi=200)
