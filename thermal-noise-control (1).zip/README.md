
# Thermal Noise Control: Simulation and Reproduction Codebase

This repository contains the complete, modular Python codebase reproducing all numerical results for the study
**"Thermal Noise Reduces Energy Cost in Stochastic Optimal Control of Double-Well Systems."**

The project includes deterministic PMP solutions, Hamilton–Jacobi–Bellman (HJB) field computations,
and Monte Carlo ensemble simulations in a structured, reproducible format.

## Directory Overview

```
thermal-noise-control/
│
├── README.md
├── requirements.txt
│
├── src/
│   ├── phase0_setup.py
│   ├── phase1_deterministic_TPBVP.py
│   ├── phase2_HJB_solver.py
│   ├── phase3_montecarlo_simulation.py
│   ├── plot_energy_scaling.py
│   ├── utils.py
│   └── __init__.py
│
├── data/
│   ├── V_store_Nt200.npy
│   ├── u_field_Nt200.npy
│   ├── Js_hjb_Nt200_D0.5_safe.npy
│   ├── mc_higherN_results.txt
│   ├── fig5_MC_FB_N10000.png
│   ├── fig_u_field_hjb_Nt200.png
│   ├── hist_Js_hjb_Nt200_safe.png
│   ├── fig_MC_prediction_N10000.png
│   └── ...
│
├── notebooks/
│   ├── analysis_and_visualization.ipynb
│   └── confidence_mapping_concept.ipynb
│
└── supplementary/
    ├── gaussian_thermal_noise_paper.pdf
    └── reference_notes.md
```

## Usage

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run simulation phases sequentially:
   ```bash
   python src/phase1_deterministic_TPBVP.py
   python src/phase2_HJB_solver.py
   python src/phase3_montecarlo_simulation.py
   python src/plot_energy_scaling.py
   ```

3. All results and figures are saved to `/data/`.

## Requirements

- numpy >= 1.24
- scipy >= 1.10
- matplotlib >= 3.8
